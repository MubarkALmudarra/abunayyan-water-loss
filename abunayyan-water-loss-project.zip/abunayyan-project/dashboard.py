"""
dashboard.py
On-premise financial-impact dashboard for water loss detection.

Designed to run as a local Streamlit server inside the company network
(e.g. alongside a Saudi Meters AMI historian or a WETICO SCADA server),
with zero outbound cloud dependency: all data stays on local disk / an
internal database connection you can swap in later (see README).
"""
import pandas as pd
import streamlit as st
import plotly.express as px

from analysis import load_data, build_baseline, detect_anomalies, summarize, project_future_cost

st.set_page_config(page_title="Water Loss Financial Impact | Abunayyan", layout="wide", page_icon="💧")

st.markdown(
    """
    <style>
    .kpi-card {background-color:#f5f7fa; border-radius:10px; padding:18px; text-align:center; border:1px solid #e3e6ea;}
    .kpi-value {font-size:28px; font-weight:700; color:#0b3d5c;}
    .kpi-label {font-size:13px; color:#5a6a7a;}
    </style>
    """,
    unsafe_allow_html=True,
)

st.title("💧 نظام تحليل الخسائر المالية الناتجة عن تسربات المياه")
st.caption("On-premise Financial Impact Engine — يعمل بالكامل على سيرفرات الشركة الداخلية دون الاعتماد على أي خدمة سحابية خارجية")

raw = load_data()
scored = detect_anomalies(build_baseline(raw))
summary = summarize(scored)

total_loss = summary["total_financial_loss_sar"].sum()
total_excess = summary["total_excess_m3"].sum()
total_leak_days = int(summary["leak_days_detected"].sum())
zones_at_risk = int((summary["total_financial_loss_sar"] > 0).sum())

c1, c2, c3, c4 = st.columns(4)
for col, label, value in zip(
    [c1, c2, c3, c4],
    ["إجمالي الخسائر المالية (SAR)", "إجمالي المياه المهدرة (m³)", "أيام التسرب المكتشفة", "عدد المواقع المتأثرة"],
    [f"{total_loss:,.0f}", f"{total_excess:,.0f}", f"{total_leak_days:,}", f"{zones_at_risk}"],
):
    col.markdown(
        f'<div class="kpi-card"><div class="kpi-value">{value}</div><div class="kpi-label">{label}</div></div>',
        unsafe_allow_html=True,
    )

st.divider()

left, right = st.columns([2, 1])

with left:
    st.subheader("الاستهلاك الفعلي مقابل الأساس المتوقع (Baseline)")
    zone_options = scored["zone_name"].unique().tolist()
    selected_zone = st.selectbox("اختر الموقع", zone_options)
    zdf = scored[scored["zone_name"] == selected_zone].sort_values("date")

    fig = px.line(
        zdf, x="date", y=["consumption_m3", "baseline_m3"],
        labels={"value": "m³", "date": "التاريخ", "variable": ""},
        color_discrete_map={"consumption_m3": "#e74c3c", "baseline_m3": "#2c7fb8"},
    )
    leak_points = zdf[zdf["predicted_leak"]]
    fig.add_scatter(
        x=leak_points["date"], y=leak_points["consumption_m3"],
        mode="markers", marker=dict(color="black", size=5, symbol="x"),
        name="تسرب مكتشف",
    )
    st.plotly_chart(fig, use_container_width=True)

    st.subheader("الأثر المالي اليومي (SAR) لهذا الموقع")
    fig2 = px.bar(zdf, x="date", y="financial_loss_sar", labels={"financial_loss_sar": "SAR", "date": ""})
    fig2.update_traces(marker_color="#c0392b")
    st.plotly_chart(fig2, use_container_width=True)

with right:
    st.subheader("ملخص الخسائر حسب الموقع")
    st.dataframe(
        summary.rename(columns={
            "zone_name": "الموقع",
            "total_consumption_m3": "إجمالي الاستهلاك (m³)",
            "leak_days_detected": "أيام التسرب",
            "total_excess_m3": "الفاقد (m³)",
            "total_financial_loss_sar": "الخسارة (SAR)",
        }),
        hide_index=True,
        use_container_width=True,
    )

    st.subheader("توقع الخسارة خلال 30 يوم القادمة إذا لم يُعالج التسرب")
    zone_id_map = dict(zip(scored["zone_name"], scored["zone_id"]))
    for zname, zid in zone_id_map.items():
        proj = project_future_cost(scored, zid, forward_days=30)
        if proj["currently_active_leak"]:
            st.error(
                f"⚠️ **{zname}**: تسرب نشط حالياً — خسارة متوقعة إضافية "
                f"**{proj['projected_loss_next_30_days_sar']:,.0f} SAR** خلال 30 يوم إذا لم يُعالج."
            )
        else:
            st.success(f"✅ **{zname}**: لا يوجد تسرب نشط حالياً.")

st.divider()
st.caption(
    "المنهجية: خط أساس متحرك (Rolling Median) مقاوم للتطرفات + كشف شذوذ بمعيار Z-score، "
    "محوّل مباشرة لتكلفة مالية عبر تعرفة المياه لكل موقع. الكود بالكامل بلا أي استدعاء إنترنت خارجي — "
    "قابل للتشغيل كخدمة داخلية على سيرفر الشركة (Docker / systemd service)."
)
