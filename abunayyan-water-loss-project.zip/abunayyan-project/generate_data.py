"""
generate_data.py
Simulates 2 years of daily smart-water-meter readings for multiple
industrial/commercial zones, with realistic seasonality and injected
leak events (of varying severity and duration).

This stands in for real historian/SCADA data that would normally be
pulled from an on-prem meter data server (e.g. a Saudi Meters AMI
deployment) via CSV export or a local database connection.
"""
import numpy as np
import pandas as pd

np.random.seed(42)

ZONES = [
    {"zone_id": "Z1", "name": "Industrial Plant - Riyadh", "base_m3": 420, "tariff_sar_per_m3": 5.5},
    {"zone_id": "Z2", "name": "Commercial Complex - Dammam", "base_m3": 180, "tariff_sar_per_m3": 6.2},
    {"zone_id": "Z3", "name": "Residential Compound - Jeddah", "base_m3": 260, "tariff_sar_per_m3": 4.8},
    {"zone_id": "Z4", "name": "Desalination Feed Line - Jubail", "base_m3": 950, "tariff_sar_per_m3": 3.9},
]

START = "2024-01-01"
DAYS = 730  # 2 years

dates = pd.date_range(START, periods=DAYS, freq="D")

records = []
for zone in ZONES:
    base = zone["base_m3"]
    # seasonal factor: higher consumption in summer months (KSA)
    seasonal = 1 + 0.28 * np.sin(2 * np.pi * (dates.dayofyear.to_numpy() - 60) / 365)
    weekly = 1 + 0.05 * np.where(dates.dayofweek.to_numpy() >= 5, -1, 1)  # slightly lower on weekends
    noise = np.random.normal(0, 0.04, DAYS)
    consumption = np.array(base * seasonal * weekly * (1 + noise), dtype=float)

    # Inject 2-3 leak events per zone: sudden step increase lasting N days
    n_leaks = np.random.randint(2, 4)
    leak_flags = np.zeros(DAYS, dtype=bool)
    for _ in range(n_leaks):
        leak_start = np.random.randint(60, DAYS - 60)
        leak_duration = np.random.randint(5, 25)
        severity = np.random.uniform(0.15, 0.55)  # 15%-55% extra volume
        end = min(leak_start + leak_duration, DAYS)
        consumption[leak_start:end] *= (1 + severity)
        leak_flags[leak_start:end] = True

    # For the demo/presentation story: force one zone (Industrial Plant)
    # to have a currently-ongoing, unresolved leak at the very end of the
    # dataset, so the dashboard's "active leak / projected future loss"
    # panel has a concrete example to show.
    if zone["zone_id"] == "Z1":
        consumption[-10:] *= 1.40
        leak_flags[-10:] = True

    for i, d in enumerate(dates):
        records.append({
            "date": d,
            "zone_id": zone["zone_id"],
            "zone_name": zone["name"],
            "consumption_m3": round(consumption[i], 2),
            "tariff_sar_per_m3": zone["tariff_sar_per_m3"],
            "is_actual_leak_period": bool(leak_flags[i]),  # ground truth, for validation only
        })

df = pd.DataFrame(records)
df.to_csv("meter_readings.csv", index=False)
print(f"Generated {len(df)} rows across {len(ZONES)} zones -> meter_readings.csv")
print(df.groupby("zone_name")["is_actual_leak_period"].sum())
