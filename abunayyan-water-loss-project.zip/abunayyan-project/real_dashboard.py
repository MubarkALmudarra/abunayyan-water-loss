# -*- coding: utf-8 -*-
"""
لوحة Streamlit مبنية بالكامل على بيانات حقيقية منشورة (real_data.py / real_analysis.py).
لا يوجد أي توليد عشوائي هنا. شغّلها بـ: streamlit run real_dashboard.py
"""
import streamlit as st
import pandas as pd
import plotly.express as px
from real_analysis import build_regional_table, national_loss_scenarios
from real_data import SOURCES, VISION2030_TARGET_LPCD, NATIONAL_DAILY_LOSS_M3_LOW, NATIONAL_DAILY_LOSS_M3_HIGH

st.set_page_config(page_title="فجوة استهلاك المياه - بيانات حقيقية", layout="wide")
st.markdown("<style>body{direction:rtl;text-align:right}</style>", unsafe_allow_html=True)

st.title("فجوة استهلاك المياه بين المناطق السعودية وهدف رؤية 2030")
st.caption("كل رقم في هذه اللوحة مصدره منشور رسميًا — لا توجد بيانات مصطنعة هنا. انظر قسم المصادر أسفل الصفحة.")

reg_df = build_regional_table()
nat_df = national_loss_scenarios()

total_excess_m3 = int(reg_df["excess_m3_per_year"].sum())
total_value_low = int(reg_df["excess_value_sar_low_tariff"].sum())
total_value_high = int(reg_df["excess_value_sar_high_tariff"].sum())

c1, c2, c3 = st.columns(3)
c1.metric("الحجم الزائد وطنيًا عن هدف 2030", f"{total_excess_m3:,} م³/سنة")
c2.metric("القيمة التوضيحية (أدنى-أعلى تعرفة)", f"{total_value_low:,} — {total_value_high:,} ريال")
c3.metric("فاقد الشبكة الوطني المُعلن رسميًا", f"{NATIONAL_DAILY_LOSS_M3_LOW:,} — {NATIONAL_DAILY_LOSS_M3_HIGH:,} م³/يوم")

st.warning(
    "تنويه منهجي: «القيمة التوضيحية» = الحجم الزائد أو المفقود × تعرفة رسمية حقيقية — "
    "وليست رقم إيرادات ضائعة فعليًا موثّق من شركة معينة، لأن الفاقد بطبيعته غير مفوتَر."
)

st.subheader("١. استهلاك الفرد اليومي حسب المنطقة مقابل هدف 2030")
plot_df = reg_df.sort_values("lpcd_2022", ascending=False)
fig = px.bar(
    plot_df, x="region", y="lpcd_2022", color="data_confirmed",
    color_discrete_map={True: "#0E7C7B", False: "#9AA39C"},
    labels={"region": "المنطقة", "lpcd_2022": "لتر/فرد/يوم", "data_confirmed": "رقم مؤكَّد؟"},
)
fig.add_hline(y=VISION2030_TARGET_LPCD, line_dash="dash", line_color="#B23A3A",
              annotation_text="هدف 2030: 150 لتر/فرد/يوم")
st.plotly_chart(fig, use_container_width=True)

st.subheader("٢. جدول الفجوة الاقتصادية لكل منطقة")
show_cols = ["region","population_2022","lpcd_2022","data_confirmed","note",
             "excess_lpcd_vs_2030_target","excess_m3_per_year",
             "excess_value_sar_low_tariff","excess_value_sar_high_tariff"]
st.dataframe(reg_df[show_cols], use_container_width=True)

st.subheader("٣. حساسية القيمة الاقتصادية لفاقد الشبكة الوطني حسب شريحة التعرفة")
scenario = st.radio("اختر السيناريو:", ["الحد الأدنى المنشور (600 ألف م³/يوم)", "الحد الأعلى المنشور (800 ألف م³/يوم)"], horizontal=True)
sub = nat_df[nat_df["loss_scenario"] == scenario]
fig2 = px.bar(sub, x="tariff_tier", y="illustrative_annual_value_sar",
              labels={"tariff_tier": "شريحة التعرفة", "illustrative_annual_value_sar": "القيمة السنوية التوضيحية (ريال)"})
st.plotly_chart(fig2, use_container_width=True)

st.subheader("المصادر")
for s in SOURCES.values():
    st.markdown(f"- [{s['title']}]({s['url']})")
